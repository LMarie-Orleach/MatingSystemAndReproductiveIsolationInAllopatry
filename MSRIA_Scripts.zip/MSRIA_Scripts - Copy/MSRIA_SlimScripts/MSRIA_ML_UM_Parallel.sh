#!/bin/bash
#SBATCH --job-name=slim
#SBATCH -n 10
#SBATCH --mem=1G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/bin/

rm ./SLiM2.sh
rm /home/genouest/cnrs_umr6553/lmarieorleac/MSRIA_ML_UM_output.txt

touch SLiM2.sh
beginning=$(date -u +%s)

iteration=1000

while [ $iteration -gt 0 ]
do
 for ChrL in 100
 do
  for N in 1000
  do
   for self_r in 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
   do
    for mu_m1 in 0
    do
     for h_m1 in 0.5
     do
      for s_m1 in 0
      do
       for mu_m2 in 1e-6
       do
        for h_m2 in 0.5
        do
         for s_m2 in 0
         do
          for mu_m3 in 0
          do
 	  for h_m3 in 0.5
           do   
            for s_m3 in 0
            do
             for r in 0.01
             do
              for GammaD_Mean in 10 100 1000 
              do
               for GammaD_Shape in 0.1 0.5 1
               do 
          
echo slim -d ChrL=${ChrL} -d N=${N} -d self_r=${self_r} -d mu_m1=${mu_m1} -d h_m1=${h_m1} -d s_m1=${s_m1} -d mu_m2=${mu_m2} -d h_m2=${h_m2} -d s_m2=${s_m2} -d mu_m3=${mu_m3} -d h_m3=${h_m3} -d s_m3=${s_m3} -d r=${r} -d GammaD_Mean=${GammaD_Mean} -d GammaD_Shape=${GammaD_Shape} MSRIA_ML_UM_Main.txt >> SLiM2.sh
                  
               done
              done             
             done
            done
           done
          done
         done
        done
       done
      done
     done
    done
   done
  done
 done
    
iteration=$(($iteration-1))
done

time parallel -a SLiM2.sh --jobs=10 --delay 0

end=$(date -u +%s)
duration=$((end-beginning))
echo $((duration))' seconds'