// Mating System and Reproductive Isolation in Allopatry
// Two-Loci C++ Models
// Compensatory mutations � MAIN
// Lucas Marie-Orleach

#include <iostream>
#include <string.h>
#include <fstream>
#include <stdio.h>
#include <time.h>
#include <cmath>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf_psi.h>
#include <vector>
#include "MSRIA_TL_MyFunctions.h"

using namespace std;

// Define parameters
unsigned long long int threshold(0);
unsigned long long int N_iter(0);
unsigned int N(0);

double mu_Aa(.0);
double mu_aA(.0);
double mu_Bb(.0);
double mu_bB(.0);

double self_r(.0);

double Fitness[10] = { 1,1,1,1,1,1,1,1,1,1 };
double ha(.0);
double sa(.0);
double hb(.0); 
double sb(.0);

double rec(.0);

double s_c(0);
double h_c(0);
double k_c(0);

int span (0);
int interval (0);

unsigned long long int genT(0);
unsigned long long int subT(0);

int main(int, char* argv[]) {

  const gsl_rng_type* T;
  gsl_rng* r;

  // create a generator chosen by the environment variable GSL_RNG_TYPE
  gsl_rng_env_setup();
  gsl_rng_default_seed = (unsigned long)time(0);
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
 
  // use argument passed in command line
  threshold=atoll(argv[1]);
  N_iter=atoll(argv[2]);
  span=atoi(argv[3]);
  interval=atoi(argv[4]);  
  
  N=atoi(argv[5]);
  self_r=atof(argv[6]);
  
  mu_Aa=mu_Bb=atof(argv[7]);
  
  ha=hb=atof(argv[8]);
  sa=sb=atof(argv[9]);
  
  rec=atof(argv[10]);
  
  k_c=atof(argv[11]);
  h_c=atof(argv[12]);
  s_c=atof(argv[13])*pow(10,atof(argv[14]));
              
  //compute Dirichlet multipliers: DIRICHLET_curved, or DIRICHLET_LINEAR
  //change function, DRIFT to DRIFT_WITH_DIRICHLET
  //add Dirichlet[int(self_r*10)] at the second position argument of the function
  //double Dirichlet[11] = { 0,0,0,0,0,0,0,0,0,0,0 };
  //DIRICHLET_CURVED(N, Dirichlet);
            
  // Compute the Meiosis_Mutation Matrix
  double Me_Matrix[10][4];
  double Mu_Matrix[4][4];
  double Me_Mu_Matrix[10][4];
  
  Me_MATRIX_COMP(rec, Me_Matrix);
  Mu_MATRIX_COMP(mu_Aa, mu_aA, mu_Bb, mu_bB, Mu_Matrix);
  Me_Mu_MATRIX_COMP(Me_Matrix, Mu_Matrix, Me_Mu_Matrix);
  		
  //Compute Fitness landsacpe
  FITNESS_LANDSCAPE_CM(sa, ha, sb, hb, s_c, h_c, k_c, Fitness);
  	
  for (int k(0); k < (int)N_iter; ++k) {
     
    //condition initialisation
    double dip_FREQ1[10] = {};
    double dip_FREQ2[10] = {};
    unsigned int dip_IND[10] = { N };
    double al_FREQ[4] = {};
      
    unsigned long long int gen(0);
    unsigned long long int genFirst(0);
    bool isfin(0);
    
    vector<vector<double>> gen_FREQ(0,vector<double>(10));
   
    //life cycle
    while (isfin == 0) {
      
      //reproduction, selection and drift routine
      REPRODUCTION(self_r, dip_IND, Me_Mu_Matrix, dip_FREQ1);
      SELECTION(dip_FREQ1, Fitness, dip_FREQ2);
      DRIFT(r, N, dip_FREQ2, dip_IND);

      //Record First substitution generation	
      if (genFirst == 0 && (dip_IND[7] + dip_IND[9] + dip_IND[9] == N || dip_IND[4] + dip_IND[6] + dip_IND[9] == N)  ) {  genFirst = gen;  }  
										 									 
      //Stop conditions						
      if (dip_IND[9] == N || gen>=threshold) {  isfin = 1;  }
      
      //record genotypic frequencies every interval
      if(span!=0 && gen%interval==0) {
        gen_FREQ.push_back(vector<double>(10));
        for (int i(0); i<=9; ++i) {
          gen_FREQ[gen/interval][i]=(double)dip_IND[i]/N;
        }
      }
      
      //add generation
      ++gen; 
    }
   
    //compute final allele frequencies
    ALLELE_FREQ_COMP(dip_IND, N, al_FREQ);
 
    //Fill in output file
    std::ofstream outfile;
    outfile.open("Output_TL_CM.csv", std::ios_base::app);
    outfile << threshold << "," << N_iter << "," << span << "," << interval << "," << N << "," << self_r << "," << mu_Aa << "," << mu_aA << "," << mu_Bb << "," << mu_bB << ",";
    outfile << ha << "," << sa << "," << hb << "," << sb << "," << rec << "," << k_c << "," << h_c << "," << s_c << "," << gen << "," << genFirst;
    if(gen!=threshold+1) {
      outfile << "," << al_FREQ[1] << "," << al_FREQ[3];
      for (int i=(int) gen_FREQ.size()-1; (i>=0) && (((int)gen_FREQ.size()-1)-i <= span) ; --i) {
        for (int j(0); j<=9; ++j){
          outfile  << "," << gen_FREQ[i][j];
        };
      }

    } outfile << std::endl;						
  }
}