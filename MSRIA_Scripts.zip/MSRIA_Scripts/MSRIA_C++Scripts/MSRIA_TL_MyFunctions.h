// Mating System and Reproductive Isolation in Allopatry
// Two-Loci C++ Models � FUNCTIONS
// Lucas Marie-Orleach

#pragma once
#include <iostream>

// Compute Meiosis Matrix given recombination rate
void Me_MATRIX_COMP_UM(double Me_Matrix[][2])
{
	double MAT[3][2] = {
		{1 ,  0},
		{.5, .5},
		{0 ,  1},
	};

	for (int i(0); i < 3; ++i) { 
		for (int j(0); j < 2; ++j) { 
			Me_Matrix[i][j] = MAT[i][j]; 
		} 
	}
}
void Me_MATRIX_COMP(const double rec, double Me_Matrix[][4])
{
	double MAT[10][4] = {
		{1,  0,  0,  0},
		{.5, .5, 0,  0},
		{.5, 0,  .5, 0},
		{.5 - (rec / 2),rec / 2,rec / 2,.5 - (rec / 2)},
		{0,  1,  0,  0},
		{rec / 2,.5 - (rec / 2),.5 - (rec / 2),rec / 2},
		{0,  .5, 0,  .5},
		{0,  0,  1,  0},
		{0,  0,  .5,.5},
		{0,  0,  0,  1}
	};

	for (int i(0); i < 10; ++i) { 
		for (int j(0); j < 4; ++j) { 
			Me_Matrix[i][j] = MAT[i][j]; 
		} 
	}
}

// Compute Mutation Matrix given mutation rates
void Mu_MATRIX_COMP_UM(const double Mu_Aa, const double Mu_aA, double Mu_Matrix[][2])
{
	double MAT[2][2] = {
		 {(1 - Mu_Aa), Mu_Aa},
		 {Mu_aA      , (1 - Mu_aA)},
	};

	for (int i(0); i < 2; ++i) {
		for (int j(0); j < 2; ++j) {
			Mu_Matrix[i][j] = MAT[i][j];
		}
	}
}
void Mu_MATRIX_COMP(const double Mu_Aa, const double mu_aA, const double mu_Bb, const double mu_bB, double Mu_Matrix[][4])
{
	double MAT[4][4] = {
		 {(1 - Mu_Aa) * (1 - mu_Bb),(1 - Mu_Aa) * mu_Bb,      Mu_Aa * (1 - mu_Bb),	     Mu_Aa * mu_Bb},
		 {(1 - Mu_Aa) * mu_bB,	     (1 - Mu_Aa) * (1 - mu_bB),Mu_Aa * mu_bB,			 Mu_Aa * (1 - mu_bB)},
		 {mu_aA * (1 - mu_Bb),	     mu_aA * mu_Bb, 		   (1 - mu_aA) * (1 - mu_Bb),(1 - mu_aA) * mu_Bb},
		 {mu_aA * mu_bB,			 mu_aA * (1 - mu_bB),	   (1 - mu_aA) * mu_bB,	     (1 - mu_aA) * (1 - mu_bB)}
	};

	for (int i(0); i < 4; ++i) {
		for (int j(0); j < 4; ++j) {
			Mu_Matrix[i][j] = MAT[i][j];
		}
	}
}

// Compute Meiose Matrix Matrix given Meiose Matrix and Mutation Matrix
void Me_Mu_MATRIX_COMP_UM(const double Me_Matrix[][2], const double Mu_Matrix[][2], double Me_Mu_Matrix[][2])
{
	double MAT[3][2] = {};
	for (int i(0); i < 3; ++i) {
		for (int j(0); j < 2; ++j) {
			for (int k(0); k < 2; ++k) {
				MAT[i][j] += Me_Matrix[i][k] * Mu_Matrix[k][j];
			}
		}
	}

	for (int i(0); i < 3; ++i) {
		for (int j(0); j < 2; ++j) {
			Me_Mu_Matrix[i][j] = MAT[i][j];
		}
	}
}
void Me_Mu_MATRIX_COMP(const double Me_Matrix[][4], const double Mu_Matrix[][4], double Me_Mu_Matrix[][4])
{
	double MAT[10][4] = {};
	for (int i(0); i < 10; ++i) {
		for (int j(0); j < 4; ++j) {
			for (int k(0); k < 4; ++k) {
				//cout << Me_Matrix[i][k] << ", " << Mu_Matrix[k][j] << ", " << Me_Matrix[i][k] * Mu_Matrix[k][j] << endl;
				MAT[i][j] += Me_Matrix[i][k] * Mu_Matrix[k][j];
			}
		}
	}

	for (int i(0); i < 10; ++i) {
		for (int j(0); j < 4; ++j) {
			Me_Mu_Matrix[i][j] = MAT[i][j];
		}
	}
}

// Compute Fitness Landscape given coefficients of dominance and strenght of selection
void FITNESS_LANDSCAPE_UM(const double sa, const double ha, const double s_wud, const double h_wud, double* Fitness)
{
	Fitness[0] = 1 ;
	Fitness[1] = (1 + (ha*sa)) * (1 + (h_wud*s_wud)) ;
	Fitness[2] = 1 + sa ;
}
void FITNESS_LANDSCAPE_CM(const double sa, const double ha, const double sb, const double hb, const double s_c, const double h_c, const double k_c, double* Fitness)
{
	Fitness[0] = 1;
	Fitness[1] = (1 + (hb * sb)) * (1 + (h_c*s_c)) ;
	Fitness[2] = (1 + (ha * sa)) * (1 + (h_c*s_c)) ;
	Fitness[3] = (1 + (ha * sa)) * (1 + (hb * sb)) * (1 + (k_c*h_c*s_c)) ;
	Fitness[4] = (1 + sb) * (1 + s_c) ;
	Fitness[5] = (1 + (ha * sa)) * (1 + (hb * sb)) * (1 + (k_c*h_c*s_c)) ;
	Fitness[6] = (1 + (ha * sa)) * (1 + sb) * (1 + (h_c*s_c)) ;
	Fitness[7] = (1 + sa) * (1 + s_c) ;
	Fitness[8] = (1 + sa) * (1 + (hb * sb)) * (1 + (h_c*s_c)) ;
	Fitness[9] = (1 + sa) * (1 + sb) ;
}
void FITNESS_LANDSCAPE_BM(const double sa, const double ha, const double sb, const double hb, const double s_B, const double h_B, const double k_B, double* Fitness)
{
	Fitness[0] = 1;
	Fitness[1] = (1 + (hb * sb));
	Fitness[2] = (1 + (ha * sa));
	Fitness[3] = (1 + (ha * sa)) * (1 + (hb * sb)) * (1 + (k_B * h_B * s_B));
	Fitness[4] = (1 + sb);
	Fitness[5] = (1 + (ha * sa)) * (1 + (hb * sb)) * (1 + (k_B * h_B * s_B));
	Fitness[6] = (1 + (ha * sa)) * (1 + sb) * (1 + (h_B * s_B));
	Fitness[7] = (1 + sa);
	Fitness[8] = (1 + sa) * (1 + (hb * sb)) * (1 + (h_B * s_B));
	Fitness[9] = (1 + sa) * (1 + sb) * (1 + s_B);
}

// Compute gamete haplotypes given adult genotypes and the Meiose Mutation Matrix
void GAMETE_PROD_UM(const unsigned int dip_IND[3], const double Me_Mu_Matrix[][2], double* hap_FREQ)
{
	for (int i(0); i < 3; ++i) {
		for (int j(0); j < 2; ++j) {
			hap_FREQ[j] += dip_IND[i] * Me_Mu_Matrix[i][j];
		}
	}
}
void GAMETE_PROD(const unsigned int dip_IND[10], const double Me_Mu_Matrix[][4], double* hap_FREQ)
{
	for (int i(0); i < 10; ++i) {
		for (int j(0); j < 4; ++j) {
			hap_FREQ[j] += dip_IND[i] * Me_Mu_Matrix[i][j];
		}
	}
}

// Define Reproduction without pollen migration function given selfing rate, genotypes of adult individuals, the Meiosis_Mutation matrix, and the Seeds's genotypic frequency 
void REPRODUCTION_UM(const double self_r, const unsigned int dip_IND[3], const double Me_Mu_Matrix[][2], double* dip_FREQ)
{	// Seed genotypes produced through selfing
	double self_dip[3] = {};
	for (int i(0); i < 3; ++i) {
		self_dip[0] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][0];
		self_dip[1] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][1] * 2;
		self_dip[2] += dip_IND[i] * Me_Mu_Matrix[i][1] * Me_Mu_Matrix[i][1];
	}

	double self_dip_SUM(0.0);
	for (int i(0); i < 3; ++i) { self_dip_SUM += self_dip[i]; }
	double self_dip_FREQ[3];
	for (int i(0); i < 3; ++i) { self_dip_FREQ[i] = self_dip[i] / self_dip_SUM; }

	// Seed genotypes produced through outcrossing
	double out_gamete[2] = {};
	GAMETE_PROD_UM(dip_IND, Me_Mu_Matrix, out_gamete);

	double out_dip[3] = {};
	out_dip[0] = out_gamete[0] * out_gamete[0];
	out_dip[1] = out_gamete[0] * out_gamete[1] * 2;
	out_dip[2] = out_gamete[1] * out_gamete[1];

	double out_dip_SUM(0.0);
	for (int i(0); i < 3; ++i) { out_dip_SUM += out_dip[i]; }
	double out_dip_FREQ[3];
	for (int i(0); i < 3; ++i) { out_dip_FREQ[i] = out_dip[i] / out_dip_SUM; }

	// Total seed Genotypes
	for (int i(0); i < 3; ++i) {
		dip_FREQ[i] = (self_r * self_dip_FREQ[i]) + ((1 - self_r) * out_dip_FREQ[i]);
	}
}
void REPRODUCTION(const double self_r, const unsigned int dip_IND[10], const double Me_Mu_Matrix[][4], double* dip_FREQ)
{	// Seed genotypes produced through selfing
	double self_dip[10] = {};
	for (int i(0); i < 10; ++i) {
		self_dip[0] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][0];
		self_dip[1] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][1] * 2;
		self_dip[2] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][2] * 2;
		self_dip[3] += dip_IND[i] * Me_Mu_Matrix[i][0] * Me_Mu_Matrix[i][3] * 2;
		self_dip[4] += dip_IND[i] * Me_Mu_Matrix[i][1] * Me_Mu_Matrix[i][1];
		self_dip[5] += dip_IND[i] * Me_Mu_Matrix[i][1] * Me_Mu_Matrix[i][2] * 2;
		self_dip[6] += dip_IND[i] * Me_Mu_Matrix[i][1] * Me_Mu_Matrix[i][3] * 2;
		self_dip[7] += dip_IND[i] * Me_Mu_Matrix[i][2] * Me_Mu_Matrix[i][2];
		self_dip[8] += dip_IND[i] * Me_Mu_Matrix[i][2] * Me_Mu_Matrix[i][3] * 2;
		self_dip[9] += dip_IND[i] * Me_Mu_Matrix[i][3] * Me_Mu_Matrix[i][3];
	}

	double self_dip_SUM(0.0);
	for (int i(0); i < 10; ++i) { self_dip_SUM += self_dip[i]; }
	double self_dip_FREQ[10];
	for (int i(0); i < 10; ++i) { self_dip_FREQ[i] = self_dip[i] / self_dip_SUM; }

	// Seed genotypes produced through outcrossing
	double out_gamete[4] = {};
	GAMETE_PROD(dip_IND, Me_Mu_Matrix, out_gamete);

	double out_dip[10] = {};
	out_dip[0] = out_gamete[0] * out_gamete[0];
	out_dip[1] = out_gamete[0] * out_gamete[1] * 2;
	out_dip[2] = out_gamete[0] * out_gamete[2] * 2;
	out_dip[3] = out_gamete[0] * out_gamete[3] * 2;
	out_dip[4] = out_gamete[1] * out_gamete[1];
	out_dip[5] = out_gamete[1] * out_gamete[2] * 2;
	out_dip[6] = out_gamete[1] * out_gamete[3] * 2;
	out_dip[7] = out_gamete[2] * out_gamete[2];
	out_dip[8] = out_gamete[2] * out_gamete[3] * 2;
	out_dip[9] = out_gamete[3] * out_gamete[3];

	double out_dip_SUM(0.0);
	for (int i(0); i < 10; ++i) { out_dip_SUM += out_dip[i]; }
	double out_dip_FREQ[10];
	for (int i(0); i < 10; ++i) { out_dip_FREQ[i] = out_dip[i] / out_dip_SUM; }

	// Total seed Genotypes
	for (int i(0); i < 10; ++i) {
		dip_FREQ[i] = (self_r * self_dip_FREQ[i]) + ((1 - self_r) * out_dip_FREQ[i]);
	}
}

// Compute genotypic frequencies after selection, given genotypic frequencies before selection, and the fitness landscape
void SELECTION_UM(const double dip_FREQ_pre_sel[3], const double Fitness[3], double* dip_FREQ_post_sel)
{
	double dip_post_sel[3] = {};
	dip_post_sel[0] = Fitness[0] * dip_FREQ_pre_sel[0];
	dip_post_sel[1] = Fitness[1] * dip_FREQ_pre_sel[1];
	dip_post_sel[2] = Fitness[2] * dip_FREQ_pre_sel[2];

	double SUM(0.0);
	for (int i(0); i < 3; ++i) { SUM += dip_post_sel[i]; }
	for (int i(0); i < 3; ++i) { dip_FREQ_post_sel[i] = dip_post_sel[i] / SUM; }
}
void SELECTION(const double dip_FREQ_pre_sel[10], const double Fitness[10], double* dip_FREQ_post_sel)
{
	double dip_post_sel[10] = {};
	dip_post_sel[0] = Fitness[0] * dip_FREQ_pre_sel[0];
	dip_post_sel[1] = Fitness[1] * dip_FREQ_pre_sel[1];
	dip_post_sel[2] = Fitness[2] * dip_FREQ_pre_sel[2];
	dip_post_sel[3] = Fitness[3] * dip_FREQ_pre_sel[3]; 
	dip_post_sel[4] = Fitness[4] * dip_FREQ_pre_sel[4];
	dip_post_sel[5] = Fitness[5] * dip_FREQ_pre_sel[5];
	dip_post_sel[6] = Fitness[6] * dip_FREQ_pre_sel[6];
	dip_post_sel[7] = Fitness[7] * dip_FREQ_pre_sel[7];
	dip_post_sel[8] = Fitness[8] * dip_FREQ_pre_sel[8];
	dip_post_sel[9] = Fitness[9] * dip_FREQ_pre_sel[9];

	double SUM(0.0);
	for (int i(0); i < 10; ++i) { SUM += dip_post_sel[i]; }
	for (int i(0); i < 10; ++i) { dip_FREQ_post_sel[i] = dip_post_sel[i] / SUM; }
}


// Define Drift function given N, seed genetoype frequencies and parents genotypes
void DRIFT_UM(const gsl_rng* r, const unsigned int N, const double dip_FREQ[], unsigned int* dip_IND)
{
	gsl_ran_multinomial(r, 3, N, dip_FREQ, dip_IND);
}
void DRIFT(const gsl_rng* r, const unsigned int N, const double dip_FREQ[], unsigned int* dip_IND)
{
	gsl_ran_multinomial(r, 10, N, dip_FREQ, dip_IND);
}

// Define Drift function given Dirichlet multiplier, N, seed genetoype frequencies and adults genotypes
void DRIFT_WITH_DIRICHLET_UM(const gsl_rng* r, const double Dirichlet_Cst, const unsigned int N, double* dip_FREQ, unsigned int* dip_IND)
{
	for (int i(0); i < 3; ++i) { /*mutiply seed frequencies by the Dirichlet multiplier*/
		dip_FREQ[i] = Dirichlet_Cst * dip_FREQ[i];
	}

	double adults_FREQ_BIS[3] = {}; /*create an empty array for the Dirichlet output*/

	gsl_ran_dirichlet(r, 3, dip_FREQ, adults_FREQ_BIS); /*Dirichlet sampling*/

	gsl_ran_multinomial(r, 3, N, adults_FREQ_BIS, dip_IND);
}
void DRIFT_WITH_DIRICHLET(const gsl_rng* r, const double Dirichlet_Cst, const unsigned int N, double* dip_FREQ, unsigned int* dip_IND)
{
	for (int i(0); i < 10; ++i) { /*mutiply seed frequencies by the Dirichlet multiplier*/
		dip_FREQ[i] = Dirichlet_Cst * dip_FREQ[i];
	}

	double adults_FREQ_BIS[10] = {}; /*create an empty array for the Dirichlet output*/

	gsl_ran_dirichlet(r, 10, dip_FREQ, adults_FREQ_BIS); /*Dirichlet sampling*/

	gsl_ran_multinomial(r, 10, N, adults_FREQ_BIS, dip_IND);
}

// Define Dirichlet functions given N
void DIRICHLET_CURVED(const unsigned int N, double Dirichlet[11])
{
	Dirichlet[0] = 0.0769231 * ((double)-1250 + (double)1237 * N);
	Dirichlet[1] = 0.037037 * ((double)-10000 + (double)9973 * N);
	Dirichlet[2] = 1e5 * N;
	Dirichlet[3] = 0.333333 * ((double)-1250 + (double)1247 * N);
	Dirichlet[4] = 0.00917431 * ((double)-10000 + (double)9891 * N);
	Dirichlet[5] = 0.00355872 * ((double)-10000 + (double)9719 * N);
	Dirichlet[6] = 0.00341297 * ((double)-5000 + (double)4707 * N);
	Dirichlet[7] = 0.000887311 * ((double)-10000 + (double)8873 * N);
	Dirichlet[8] = 0.000465766 * ((double)-10000 + (double)7853 * N);
	Dirichlet[9] = 0.000232937 * ((double)-10000 + (double)5707 * N);
	Dirichlet[10] = 0.000115701 * ((double)-10000 + (double)1357 * N);
}
void DIRICHLET_LINEAR(const unsigned int N, double Dirichlet[11])
{
	Dirichlet[0] = 1e5 * N;
	Dirichlet[1] = 0.0169492 * ((double)-5000 + (double)4941 * N);
	Dirichlet[2] = 0.00291545 * ((double)-10000 + (double)9657 * N);
	Dirichlet[3] = 0.0238095 * ((double)-625 + (double)583 * N);
	Dirichlet[4] = 0.000898473 * ((double)-10000 + (double)8887 * N);
	Dirichlet[5] = 0.000594177 * ((double)-10000 + (double)8317 * N);
	Dirichlet[6] = 0.00165837 * ((double)-2500 + (double)1897 * N);
	Dirichlet[7] = 0.000299312 * ((double)-10000 + (double)6659 * N);
	Dirichlet[8] = 0.00110254 * ((double)-2000 + (double)1093 * N);
	Dirichlet[9] = 0.00131752 * ((double)-1250 + (double)491 * N);
	Dirichlet[10] = 0.000627746 * ((double)-2000 + (double)407 * N);
}

// Compute allele frequencies
void ALLELE_FREQ_COMP(const unsigned int* dip_IND, double N, double* allele_FREQ) 
{
	allele_FREQ[0] = ((2 * (double)dip_IND[0]) + (2 * (double)dip_IND[1]) + (double)dip_IND[2] + (double)dip_IND[3] + (2 * (double)dip_IND[4]) + (double)dip_IND[5] + (double)dip_IND[6]) / (2 * N); // A
	allele_FREQ[1] = ((double)dip_IND[2] + (double)dip_IND[3] + (double)dip_IND[5] + (double)dip_IND[6] + (2 * (double)dip_IND[7]) + (2 * (double)dip_IND[8]) + (2 * (double)dip_IND[9])) / (2 * N); // a
	allele_FREQ[2] = ((2 * (double)dip_IND[0]) + (double)dip_IND[1] + (2 * (double)dip_IND[2]) + (double)dip_IND[3] + (double)dip_IND[5] + (2 * (double)dip_IND[7]) + (double)dip_IND[8]) / (2 * N); // B
	allele_FREQ[3] = ((double)dip_IND[1] + (double)dip_IND[3] + (2 * (double)dip_IND[4]) + (double)dip_IND[5] + (2 * (double)dip_IND[6]) + (double)dip_IND[8] + (2 * (double)dip_IND[9])) / (2 * N); // b
}		 