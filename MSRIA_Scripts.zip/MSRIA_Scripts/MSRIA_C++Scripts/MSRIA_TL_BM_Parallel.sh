#!/bin/bash
#SBATCH --job-name=msri
#SBATCH -n 11
#SBATCH --mem=1G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/MSRI/

rm ./a.out
rm ./ColumnHeader*.csv
rm ./msri
rm ./Output*.csv
rm ./Parallel2.sh


g++ -L/lib64 -lgsl -lgslcblas -lm -O3 -I /local/boost/1.61/ -Wall -Wextra -o msri -c ./MSRIA_TL_BM_Main.cpp -std=c++11 
g++ ./msri -lgsl -lgslcblas -lm 

touch Output_TL_BM.csv
touch Parallel2.sh

threshold=$(echo 10^9 | bc)
iteration=$(echo 10^4 | bc)

span=0
interval=$(echo 10^1 | bc)

for N in 10000
do
 for self_r in 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 do
  for mu in 2.5e-7 2.5e-6 2.5e-5 
  do
   for h in 0.5
   do   
    for s in 0
    do 
     for rec in 0.5  
     do     
      for h_B in 0.1 0.5 0.9
      do
       for s_B in -2.5
       do
        for s_B_exponent in -4
        do    
                   
         echo ./a.out ${threshold} ${iteration} ${span} ${interval} ${N} ${self_r} ${mu} ${h} ${s} ${rec} ${h_B} ${s_B} ${s_B_exponent} >> Parallel2.sh 
        
        done          
       done
      done
     done
    done
   done
  done
 done
done

time parallel -a Parallel2.sh --jobs 11 --delay 1

printf "threshold, iteration, span, interval, N, self_r, mu_Aa, mu_aA, mu_Bb, mu_bB, ha, sa, hb, sb, rec, h_B, k_B, s_B, gen, a_FREQ_gen, b_FREQ_gen," >> ColumnHeader_BM.csv
printf "AB/AB_0,AB/Ab_0,AB/aB_0,AB/ab_0,Ab/Ab_0,Ab/aB_0,Ab/ab_0,aB/aB_0,aB/ab_0,ab/ab_0" >> ColumnHeader_BM.csv

counter=1
while [ $counter -le $span ]
do
  printf ",AB/AB_-"$((interval*counter))",AB/Ab_-"$((interval*counter))",AB/aB_-"$((interval*counter))",AB/ab_-"$((interval*counter))",Ab/Ab_-"$((interval*counter))",Ab/aB_-"$((interval*counter))",Ab/ab_-"$((interval*counter))",aB/aB_-"$((interval*counter))",aB/ab_-"$((interval*counter))",ab/ab_-"$((interval*counter))"" >> ColumnHeader_BM.csv
  counter=$(($counter+1))
done

printf "\n" >> ColumnHeader_BM.csv