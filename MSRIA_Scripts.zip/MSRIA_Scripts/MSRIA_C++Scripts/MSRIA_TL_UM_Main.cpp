// Mating System and Reproductive Isolation in Allopatry
// Two-Loci C++ Models
// Underdominant mutations � MAIN
// Lucas Marie-Orleach

#include <iostream>
#include <string.h>
#include <fstream>
#include <stdio.h>
#include <time.h>
#include <cmath>
#include "gsl/gsl_rng.h"
#include "gsl/gsl_randist.h"
#include "gsl/gsl_cdf.h"
#include "gsl/gsl_math.h"
#include "gsl/gsl_sf_psi.h"
#include <vector>
#include "MSRIA_TL_MyFunctions.h"

using namespace std;

// Define parameters
unsigned long long int threshold(0);
unsigned long long int N_iter(0);
unsigned int N(0);

double mu_Aa(.0);
double mu_aA(.0);

double self_r(.0);

double Fitness[3] = { 1,1,1 };
double h(.0);
double s(.0);

double h_u(0);
double s_u(.0);

unsigned long long int genT(0);
unsigned long long int subT(0);

int main(int, char* argv[]) {

  const gsl_rng_type* T;
  gsl_rng* r;
 
  // create a generator chosen by the environment variable GSL_RNG_TYPE
  gsl_rng_env_setup();
  gsl_rng_default_seed = (unsigned long)time(0);
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);

  // use argument passed in command line
  threshold=atoll(argv[1]);
  N_iter=atoll(argv[2]);
  N=atoi(argv[3]);

  self_r=atof(argv[4]);
  
  mu_Aa=atof(argv[5]);
  
  h=atof(argv[6]);
  s=atof(argv[7]);
  
  h_u=atof(argv[8]);
  s_u=atof(argv[9]);
  
  //compute Dirichlet multipliers: DIRICHLET_curved or DIRICHLET_LINEAR
  //change function, DRIFT_UM to DRIFT_WITH_DIRICHLET_UM
  //and insert Dirichlet[int(self_r*10)] as the second argument of the function
  //double Dirichlet[11] = { 0,0,0,0,0,0,0,0,0,0,0 };
  //DIRICHLET_LINEAR(N, Dirichlet);

  // Compute the Meiosis_Mutation Matrix
  double Me_Matrix[3][2];
  double Mu_Matrix[2][2];
  double Me_Mu_Matrix[3][2];
  
  Me_MATRIX_COMP_UM(Me_Matrix);
  Mu_MATRIX_COMP_UM(mu_Aa, mu_aA, Mu_Matrix);
  Me_Mu_MATRIX_COMP_UM(Me_Matrix, Mu_Matrix, Me_Mu_Matrix); 
 
  //Compute Fitness landsacpe
  FITNESS_LANDSCAPE_UM(s, h, s_u, h_u, Fitness);

  for (int k(0); k < (int)N_iter; ++k) {		  
            
      //condition initialisation
      double dip_FREQ1[3] = {};
      double dip_FREQ2[3] = {};
      unsigned int dip_IND[3] = { N,0,0 };
      
      unsigned long long int gen(0);
      bool isfin(0);
   
      //life cycle
      while (isfin == 0) {
        //reproduction, selection and drift routine
      	REPRODUCTION_UM(self_r, dip_IND, Me_Mu_Matrix, dip_FREQ1);
        SELECTION_UM(dip_FREQ1, Fitness, dip_FREQ2);
        DRIFT_UM(r, N, dip_FREQ2, dip_IND);
  										 									 
        //Stop conditions						
        if (dip_IND[2] == N || gen>=threshold) {  isfin = 1;  }
 
        //add generation
        ++gen;
      }

    genT += gen;
	subT += trunc(dip_IND[2] / N);

    }
    
    //Fill in output file
    std::ofstream outfile;
    outfile.open("Output_TL_UM.csv", std::ios_base::app);
    outfile << threshold << "," << N_iter << "," << N << "," << self_r << "," << mu_Aa << "," << mu_aA << "," ; 
    outfile << h << "," << s << "," << h_u << "," << s_u << "," << (double)genT/N_iter << "," << (double)subT / N_iter;
    outfile << std::endl;
}