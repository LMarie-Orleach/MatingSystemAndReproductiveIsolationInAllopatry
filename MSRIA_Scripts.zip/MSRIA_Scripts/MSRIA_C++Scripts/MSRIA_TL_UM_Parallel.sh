#!/bin/bash
#SBATCH --job-name=msri
#SBATCH -n 48
#SBATCH --mem=1G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/MSRI/

rm ./a.out
rm ./ColumnHeader_UM.csv
rm ./msri
rm ./Output*.csv
rm ./Parallel2.sh

g++ -L/lib64 -lgsl -lgslcblas -lm -O3 -I /local/boost/1.61/ -Wall -Wextra -o msri -c ./MSRIA_TL_UM_Main.cpp -std=c++11 
g++ ./msri -lgsl -lgslcblas -lm 

touch Output_TL_UM.csv
touch Parallel2.sh

threshold=$(echo 10^9 | bc)
iteration=$(echo 10^3 | bc)

for N in 500
do
 for self_r in 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 do
  for mu in 1e-6
  do
   for h in 1
   do   
    for s in 0
    do 
     for h_u in 1
     do
      for s_u in -1e-3 -2e-3 -1e-2
      do
                  
       echo ./a.out ${threshold} ${iteration} ${N} ${self_r} ${mu} ${h} ${s} ${h_u} ${s_u} >> Parallel2.sh 
        
      done     
     done
    done
   done
  done
 done
done

time parallel -a Parallel2.sh --jobs 48 --delay 1 

printf "threshold, iteration, N, self_r, mu_Aa, mu_aA, h, s, h_u, s_u, gen, Psub" >> ColumnHeader_UM.csv
printf "\n" >> ColumnHeader_UM.csv