#!/bin/bash
#SBATCH --job-name=curved
#SBATCH -n 48
#SBATCH --mem=1G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/MSRI/

rm ./a.out
rm ./ColumnHeader*.csv
rm ./msri
rm ./Output*.csv
rm ./Parallel2.sh


g++ -L/lib64 -lgsl -lgslcblas -lm -O3 -I /local/boost/1.61/ -Wall -Wextra -o msri -c ./MSRIA_TL_CM_Main.cpp -std=c++11 
g++ ./msri -lgsl -lgslcblas -lm 

touch Output_TL_CM.csv
touch Parallel2.sh

threshold=$(echo 10^9 | bc)
iteration=$(echo 10^3 | bc)

span=0
interval=$(echo 10^1 | bc)

for N in 1000
do
 for self_r in 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
 do
  for mu in 1e-5
  do
   for h in 0.5
   do   
    for s in 0
    do 
     for rec in 0 0.001 0.01 0.1 0.5
     do 
      for k_c in 0 1
      do    
       for h_c in 0.5
       do
        for s_c in -0.005 -0.01 -0.025
        do
         for s_c_exponent in 0
         do    
                   
          echo ./a.out ${threshold} ${iteration} ${span} ${interval} ${N} ${self_r} ${mu} ${h} ${s} ${rec} ${k_c} ${h_c} ${s_c} ${s_c_exponent} >> Parallel2.sh 
       
         done 
        done          
       done
      done
     done
    done
   done
  done
 done
done

time parallel -a Parallel2.sh --jobs 48 --delay 1

printf "threshold, iteration, span, interval, N, self_r, mu_Aa, mu_aA, mu_Bb, mu_bB, ha, sa, hb, sb, rec, k_eud, h_eud, s_eud, gen, genFirst, a_FREQ_gen, b_FREQ_gen," >> ColumnHeader_CM.csv
printf "AB/AB_0,AB/Ab_0,AB/aB_0,AB/ab_0,Ab/Ab_0,Ab/aB_0,Ab/ab_0,aB/aB_0,aB/ab_0,ab/ab_0" >> ColumnHeader_CM.csv

counter=0
while [ $counter -le $span ]
do
  printf ",AB/AB_-"$((interval*(counter+1)))",AB/Ab_-"$((interval*(counter+1)))",AB/aB_-"$((interval*(counter+1)))",AB/ab_-"$((interval*(counter+1)))",Ab/Ab_-"$((interval*(counter+1)))",Ab/aB_-"$((interval*(counter+1)))",Ab/ab_-"$((interval*(counter+1)))",aB/aB_-"$((interval*(counter+1)))",aB/ab_-"$((interval*(counter+1)))",ab/ab_-"$((interval*(counter+1)))"" >> ColumnHeader_CM.csv
  counter=$(($counter+1))
done

printf "\n" >> ColumnHeader_CM.csv