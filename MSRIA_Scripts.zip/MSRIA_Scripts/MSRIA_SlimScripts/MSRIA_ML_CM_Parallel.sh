#!/bin/bash
#SBATCH --job-name=slim
#SBATCH -n 48
#SBATCH --mem=10G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/bin/

rm ./SLiM2.sh
rm /home/genouest/cnrs_umr6553/lmarieorleac/MSRIA_ML_CM_output.txt

touch SLiM2.sh

iteration=100

while [ $iteration -gt 0 ]
do
 for ChrL in 100
 do
  for N in 200
  do
   for self_r in 0 0.25 0.5 0.75 1
   do
    for mu_m1 in 0
    do
     for h_m1 in 0.5
     do
      for s_m1 in 0
      do
       for mu_m2 in 1*10^-6
       do
        for h_m2 in 0.5
        do
         for s_m2 in 0
         do
          for mu_m3 in 0
          do
 	   for h_m3 in 0.5
           do   
            for s_m3 in 0
            do
             for r in 0 0.0001 0.001 0.01
             do
              for k_c in 0 1
              do
               for h_c in 0.5
               do
                for s_c in -0.04
                do
          
echo slim -d ChrL=${ChrL} -d N=${N} -d self_r=${self_r} -d mu_m1=${mu_m1} -d h_m1=${h_m1} -d s_m1=${s_m1} -d mu_m2=${mu_m2} -d h_m2=${h_m2} -d s_m2=${s_m2} -d mu_m3=${mu_m3} -d h_m3=${h_m3} -d s_m3=${s_m3} -d r=${r} -d k_c=${k_c} -d h_c=${h_c} -d s_c=${s_c} MSRIA_ML_CM_Main.txt >> SLiM2.sh
                  
                done
	       done
              done             
             done
            done
           done
          done
         done
        done
       done
      done
     done
    done
   done
  done
 done
    
iteration=$(($iteration-1))
done

time parallel -a SLiM2.sh --jobs=48 --delay 1