#!/bin/bash
#SBATCH --job-name=slim
#SBATCH -n 30
#SBATCH --mem=10G
#SBATCH -p ecobio

. /local/env/envconda.sh
conda activate /home/genouest/cnrs_umr6553/lmarieorleac/my_env
. /local/env/envparallel-20190122.sh
cd /home/genouest/cnrs_umr6553/lmarieorleac/my_env/bin/

rm ./SLiM2.sh
rm /home/genouest/cnrs_umr6553/lmarieorleac/MSRIA_ML_BM_output.txt

touch SLiM2.sh

iteration=1000

while [ $iteration -gt 0 ]
do
 for ChrL in 1000
 do
  for N in 1000
  do
   for self_r in 0 0.25 0.5 0.75 1
   do
    for mu_m1 in 0
    do
     for h_m1 in 0.5
     do
      for s_m1 in 0
      do
       for mu_m2 in 2.5*10^-9 2.5*10^-8 2.5*10^-7
       do
        for h_m2 in 0.5
        do
         for s_m2 in 0
         do
          for mu_m3 in 0
          do
           for h_m3 in 0.5
           do   
            for s_m3 in 0
            do
             for r in 10^-3
             do
              for h_B in 0.5
              do
               for k_B in 0.5
               do
                for s_B in -1*10^-2
                do
          
echo slim -d ChrL=${ChrL} -d N=${N} -d self_r=${self_r} -d mu_m1=${mu_m1} -d h_m1=${h_m1} -d s_m1=${s_m1} -d mu_m2=${mu_m2} -d h_m2=${h_m2} -d s_m2=${s_m2} -d mu_m3=${mu_m3} -d h_m3=${h_m3} -d s_m3=${s_m3} -d r=${r} -d h_B=${h_B} -d k_B=${k_B} -d s_B=${s_B} MSRIA_ML_BM_Main.txt >> SLiM2.sh
               
		done   
               done
              done             
             done
            done
           done
          done
         done
        done
       done
      done
     done
    done
   done
  done
 done
    
iteration=$(($iteration-1))
done

time parallel -a SLiM2.sh --jobs=48 --delay 1