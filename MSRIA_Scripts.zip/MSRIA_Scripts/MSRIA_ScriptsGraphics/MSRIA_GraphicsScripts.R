### script generation all graphics presented in Marie-Orleach et al, PLoS Genetics, 2023
### Lucas Marie-Orleach, Nov 2022
### lucas.marie-orleach@univ-rennes1.fr

library(readr) # for read_csv
library(tidyr) # for pivot_longer
library(stringr) # for str_sub
library(ggplot2) # for ggplot
library(ggthemes) # for theme_classic
library("scales") # for trans_break
library(pracma) # for erf
library(plot3D)
library(dplyr)
library(plyr)
library(fitdistrplus)
library(RColorBrewer)


##############################################
################## FIGURE 2 ##################
##############################################

setwd("C:/Users/lucasm/Desktop/MSRIA_GRAPHICS")
Dataset_2 <- read_table("S1_Table.txt")
names(Dataset_2)

TRatioApprox = function(B,self_r) ((1-self_r)^B)

Dataset_2 <- ddply(Dataset_1, .(GammaD_Mean,GammaD_Shape,self_r), summarize, generation=mean(generation))
Dataset_2$ref <- NA
Dataset_2$rel <- NA
for (i in 1:nrow(Dataset_2)) {
  if (Dataset_2$self_r[i]==0) {Dataset_2$ref[i]=Dataset_2$generation[i];}
  else {Dataset_2$ref[i]=Dataset_2$ref[i-1];}
  Dataset_2$rel[i]=Dataset_2$generation[i]/Dataset_2$ref[i];
  Dataset_2$Approx[i] <- TRatioApprox( Dataset_2$GammaD_Shape[i], Dataset_2$self_r[i] );
}

Fig2 <- ggplot(Dataset_2, aes(x=self_r, y=rel, group=interaction(factor(GammaD_Mean),factor(GammaD_Shape)))) +
  stat_summary(size=3, fun.data=mean_se, geom="point", 
               aes(group=interaction(factor(GammaD_Mean),factor(GammaD_Shape)), colour=factor(GammaD_Shape), shape=factor(GammaD_Mean))) +
  geom_function(fun=function(x) TRatioApprox(0.1, x)+1e-9, color="#1965B0", size=1) +
  geom_function(fun=function(x) TRatioApprox(0.5, x)+1e-9, color="#F7F056", size=1) +
  geom_function(fun=function(x) TRatioApprox(1, x)+1e-9, color="#DC050C", size=1) +
  scale_color_manual(values=c("#1965B0","#F7F056", "#DC050C")) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  theme(axis.text = element_blank(),axis.title = element_blank(),legend.position="none")


##############################################
################## FIGURE 3 ##################
##############################################

# Fig3A FITNESS LANDSCAPES
# Fig3A_1 FITNESS LANDSCAPE FOR K=0
sc=0.5
hc=0.5
kc=0

x=1:3
y=1:3
z = matrix ( c(1,1-(sc*hc),1-sc,1-(sc*hc),1-(sc*hc*kc),1-(sc*hc),1-sc,1-(sc*hc),1), nrow=3, ncol=3, byrow=T)
hist3D(x,y,z, zlim=c(0,1), col="grey", border="black", theta=45, phi=25, axes=T, label=T, space=0.25, lighting=T, shade=0.5)

# Fig3A_2 FITNESS LANDSCAPE FOR K=1
sc=0.5
hc=0.5
kc=1

x=1:3
y=1:3
z = matrix ( c(1,1-(sc*hc),1-sc,1-(sc*hc),1-(sc*hc*kc),1-(sc*hc),1-sc,1-(sc*hc),1), nrow=3, ncol=3, byrow=T)
hist3D(x,y,z, zlim=c(0,1.2), col="grey90", border="black", theta=45, phi=25, axes=T, label=T, space=0.25, lighting=T, shade=0.5)

# Fig3B TIME TO FIXATION
# ANALYTICAL APPROXIMATIONS (SEE MATHAMTICA FILE)
Tfixrk = function (N, F, r, h, k, s, u) { ((F*(1-h)+h)*s) /
    ( (2*u*u) * (N+( (N*erf(  ((-1+F)*(-1+N)*(r+(h*k*s))) / ((sqrt(1-(F*F)))*(sqrt(N*(r+(h*k*s))))) )) /
                       (erf(  ((1-F)*sqrt(N*(r+(h*k*s)))) / (sqrt(1-(F*F))) )) )) )
  }

# SIMULATIONS OUTPUTS
Dataset_3B <- read_csv("S2_Table.csv")

# COMPUTE ESTIMATED MEANS FOR RIGHT CENSORED DATA THROUGH FITDISTRIPLUS
SUMMARY <- Dataset_3B %>% filter(s_eud==-0.01) %>% group_by(k_eud, s_eud, rec, self_r) %>% dplyr::summarise(mean=mean(gen))
for (i in 1:nrow(SUMMARY)){
  df <- data.frame(left <- subset(Dataset_3B, k_eud==SUMMARY$k_eud[i] & s_eud==SUMMARY$s_eud[i] & rec==SUMMARY$rec[i] & self_r==SUMMARY$self_r[i])$gen)
  colnames(df) = "left"
  right <- lapply(df$left, function(x) ifelse(x==1000000001, "NA", x))
  df <- data.frame(left, as.numeric(right))
  colnames(df) = c("left","right")
  
  fdf.gamma <- fitdistcens(df/(10^9), "gamma")
  SUMMARY$gamma[i] <- summary(fdf.gamma)$estimate[1]/ (summary(fdf.gamma)$estimate[2] / (10^9))
  
  fdf.lnorm <- fitdistcens(df, "lnorm")
  SUMMARY$lnorm[i] <- exp(summary(fdf.lnorm)$estimate[1]+((summary(fdf.lnorm)$estimate[2]^2)/2))
  
  SUMMARY$AdjustedMean[i] <- if (SUMMARY$gamma[i]>10^9) {10^9} else {SUMMARY$gamma[i]}
}

# Fig3B_1 TIME TO FIXATION FOR K=0
Fig3B_1 <- ggplot(subset(Dataset_3B, k_eud==0 & s_eud==-0.01 & rec != 0.5), aes(x=self_r, y=gen, group_by(factor(rec)))) +
  coord_trans(y="log10") +
  scale_y_continuous(breaks = trans_breaks("log10", function(x) 10^x), limit=c(10^7,10^9.1), labels = trans_format("log10", math_format(10^.x))) +
  geom_hline(yintercept=1e9, linetype="dashed", size=1) +
  
  geom_point(data=subset(SUMMARY, k_eud==0 & s_eud==-0.01 & rec == 0.0), aes(y=AdjustedMean, x=self_r), color="grey0", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==0 & s_eud==-0.01 & rec == 0.001), aes(y=AdjustedMean, x=self_r), color="grey50", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==0 & s_eud==-0.01 & rec == 0.01), aes(y=AdjustedMean, x=self_r), color="grey75", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==0 & s_eud==-0.01 & rec == 0.1), aes(y=AdjustedMean, x=self_r), color="grey90", size=4) +
  
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=1e-9, h=0.5, k=0 , s=0.01, u=10^-5), color="grey0", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.001, h=0.5, k=0 , s=0.01, u=10^-5), color="grey50", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.01, h=0.5, k=0 , s=0.01, u=10^-5), color="grey75", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.1, h=0.5, k=0 , s=0.01, u=10^-5), color="grey90", size=1) +
  
  theme_classic(base_size=25) +
  theme(aspect.ratio=1, axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 


# Fig3B_2 TIME TO FIXATION FOR K=1
Fig3B_2 <- ggplot(subset(Dataset_3B, k_eud==1 & s_eud==-0.01 & rec != 0.5), aes(x=self_r, y=gen, group_by(factor(rec)))) +
  coord_trans(y="log10") +
  scale_y_continuous(breaks = trans_breaks("log10", function(x) 10^x), limit=c(10^7,10^9.1), labels = trans_format("log10", math_format(10^.x))) +
  geom_hline(yintercept=1e9, linetype="dashed", size=1) +
  
  geom_point(data=subset(SUMMARY, k_eud==1 & s_eud==-0.01 & rec == 0.0), aes(y=AdjustedMean, x=self_r), color="grey0", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==1 & s_eud==-0.01 & rec == 0.001), aes(y=AdjustedMean, x=self_r), color="grey50", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==1 & s_eud==-0.01 & rec == 0.01), aes(y=AdjustedMean, x=self_r), color="grey75", size=4) +
  geom_point(data=subset(SUMMARY, k_eud==1 & s_eud==-0.01 & rec == 0.1), aes(y=AdjustedMean, x=self_r), color="grey90", size=4) +
  
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0, h=0.5, k=1 , s=0.01, u=10^-5), color="grey0", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.001, h=0.5, k=1 , s=0.01, u=10^-5), color="grey50", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.01, h=0.5, k=1 , s=0.01, u=10^-5), color="grey75", size=1) +
  geom_function(fun=function(x) Tfixrk(N=1000, F=(x/(2-x)), r=0.1, h=0.5, k=1 , s=0.01, u=10^-5), color="grey90", size=1) +
  
  theme_classic(base_size=25) +
  theme(aspect.ratio=1, axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 


# Fig3C GENOTYPIC FREQUENCIES GRAPHS
Dataset_3C <- read_csv("S3_Table.csv")

FitnessVec <- function(k_eud,h_eud,s_eud) { c(1, 1-(h_eud*s_eud), 1-(h_eud*s_eud), 1-(k_eud*h_eud*s_eud), 
                                              1-s_eud, 1-(k_eud*h_eud*s_eud), 1-(h_eud*s_eud),
                                              1-s_eud, 1-(h_eud*s_eud), 
                                              1) }

Dataset_3C.long <- pivot_longer(Dataset_3C, cols=c(22:231), names_to = "label", values_to = "freq")
Dataset_3C.long$genotype <- str_sub(Dataset_3C.long$label, 1, 5)
Dataset_3C.long$TimePoint <- as.numeric(str_sub(Dataset_3C.long$label, 7))

Dataset_3C.long_S <- Dataset_3C.long %>% group_by(self_r, mu_Aa, ha, sa, rec, k_eud, h_eud, s_eud, TimePoint, genotype) %>% dplyr::summarise(mean(freq, na.rm=TRUE))
Dataset_3C.long_S$genotype_bis <- rep(c(10:1),nrow(Dataset_3C.long_S)/10)
Dataset_3C.long_S$Fitness <- NA
for (i in 1:nrow(Dataset_3C.long_S)) {
  Dataset_3C.long_S$Fitness[i] = Dataset_3C.long_S$`mean(freq, na.rm = TRUE)`[i] * FitnessVec(k_eud=Dataset_3C.long_S$k_eud[i],h_eud=Dataset_3C.long_S$h_eud[i],s_eud=-Dataset_3C.long_S$s_eud[i])[ Dataset_3C.long_S$genotype_bis[i] ] 
}

Dataset_3C.long_SS <- Dataset_3C.long_S %>% group_by(self_r, mu_Aa, ha, sa, rec, k_eud, h_eud, s_eud, TimePoint) %>% dplyr::summarise((sum(Fitness)-0.99)*100)

# Fig3C_GENOTYPIC FREQ - rec=0, k=0, self-r=0 
Fig3C_1 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==0 & self_r==0.0 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==0 & self_r==0.0 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none")

# Fig3C_GENOTYPIC FREQ - rec=0, k=0, self-r=0.6 
Fig3C_2 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==0 & self_r==0.6 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==0 & self_r==0.6 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none")


# Fig3C_GENOTYPIC FREQ - rec=0, k=0, self-r=1 
Fig3C_3 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==0 & self_r==1 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==0 & self_r==1 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

# Fig3C_GENOTYPIC FREQ - rec=0, k=1, self-r=0 
Fig3C_4 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==1 & self_r==0.0 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==1 & self_r==0.0 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

# Fig3C_GENOTYPIC FREQ - rec=0, k=1, self-r=0.6 
Fig3C_5 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==1 & self_r==0.6 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==1 & self_r==0.6 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 


# Fig3C_GENOTYPIC FREQ - rec=0, k=1, self-r=1 
Fig3C_6 <- ggplot(subset(Dataset_3C.long, rec==0 & k_eud==1 & self_r==1 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0 & k_eud==1 & self_r==1 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

# Fig3C_GENOTYPIC FREQ - rec=0.5, k=0, self-r=0 
Fig3C_7 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==0 & self_r==0.0 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==0 & self_r==0.0 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none")

# Fig3C_GENOTYPIC FREQ - rec=0.5, k=0, self-r=0.6 
Fig3C_8 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==0 & self_r==0.6 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==0 & self_r==0.6 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none")


# Fig3C_GENOTYPIC FREQ - rec=0.5, k=0, self-r=1 
Fig3C_9 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==0 & self_r==1 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==0 & self_r==1 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

# Fig3C_GENOTYPIC FREQ - rec=0.5, k=1, self-r=0 
Fig3C_10 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==1 & self_r==0.0 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==1 & self_r==0.0 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

# Fig3C_GENOTYPIC FREQ - rec=0.5, k=1, self-r=0.6 
Fig3C_11 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==1 & self_r==0.6 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==1 & self_r==0.6 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 


# Fig3C_GENOTYPIC FREQ - rec=0.5, k=1, self-r=1 
Fig3C_12 <- ggplot(subset(Dataset_3C.long, rec==0.01 & k_eud==1 & self_r==1 & s_eud==-0.01), aes(x=TimePoint, y=freq, group_by(genotype))) +
  stat_summary(size=1, fun.data=mean_se, na.rm=T, geom="line", aes(group=genotype, colour=genotype)) +
  scale_color_manual(values=c("#DC050C", "#CAE0AB", "#F7F056", "#CAE0AB", "#4EB265", "#F7F056", "#4EB265", "#7BAFDE", "#7BAFDE", "#1965B0")) +
  geom_point(shape=20, data=subset(Dataset_3C.long_SS, rec==0.01 & k_eud==1 & self_r==1 & s_eud==-0.01),aes(x=TimePoint, y=`(sum(Fitness) - 0.99) * 100`)) + 
  scale_y_continuous(sec.axis = sec_axis(~., name = "fitness")) +
  theme_classic(base_size=17) +
  theme(axis.text = element_blank(), axis.title = element_blank(), strip.text = element_blank(), legend.position="none") 

r1 <- plot_grid(Fig3B_1, Fig3B_2, ncol=2, nrow=1)
r2 <- plot_grid(Fig3C_1,  Fig3C_2,  Fig3C_3, Fig3C_4,  Fig3C_5,  Fig3C_6, ncol=6, nrow=1)
r3 <- plot_grid(Fig3C_7,  Fig3C_8,  Fig3C_9, Fig3C_10,  Fig3C_11,  Fig3C_12, ncol=6, nrow=1)

Fig3 <- plot_grid(r1, r3, r2, nrow = 3, rel_heights = c(3, 1, 1))


##############################################
################## FIGURE 5 ##################
##############################################

# Fig5A N
Dataset_5A <- read_csv("S4_Table.csv")
Fig5A <- ggplot(Dataset_5A, aes(x=N, y=gen, group_by(s_BDMi))) +
  coord_trans(y="log10", x="log10", ylim=c(NA,NA)) +
  scale_y_continuous(breaks=c(2e4,3e4,4e4,5e4,6e4,7e4,8e4,9e4,1e5,
                              2e5,3e5,4e5,5e5,6e5,7e5,8e5,9e5,1e6,
                              2e6,3e6,4e6,5e6,6e6,7e6,8e6,9e6,1e7)) +
  scale_x_continuous(breaks=c(1e2,1e3,1e4,1e5,1e6)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(s_BDMi), fill=factor(s_BDMi))) +
  scale_fill_manual(values=c("#DC050C", "#1965B0")) +
  theme(legend.position="none")

# Fig5B h
Dataset_5B <- read_csv("S5_Table.csv")
Fig5B <- ggplot(Dataset_5B, aes(x=h_BDMi, y=gen, group_by(s_BDMi))) +
  coord_trans(ylim=c(NA,NA)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(s_BDMi), fill=factor(s_BDMi))) +
  scale_fill_manual(values=c("#DC050C", "#1965B0")) +
  theme(legend.position="none")

# Fig 5C r
Dataset_5C <- read_csv("S6_Table.csv")
Fig5C <- ggplot(Dataset_5C, aes(x=rec, y=gen, group_by(s_BDMi))) +
  coord_trans(x="log10", xlim=c(NA,NA)) +
  scale_x_continuous(breaks=c(1e-9,1e-7,1e-5,1e-3,1e-1)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(s_BDMi), fill=factor(s_BDMi))) +
  scale_fill_manual(values=c("#DC050C", "#1965B0")) +
  theme(legend.position="none")

# Fig 5D mu
Dataset_5D <- read_csv("S7_Table.csv")
Fig5D <- ggplot(subset(Dataset_5D,mu_Aa<=1e-4 & s_BDMi!=-2.5e-4), aes(x=mu_Aa, y=gen, group_by(s_BDMi))) +
  coord_trans(y="log10", x="log10", ylim=c(1e4,1e7)) +
  scale_y_continuous(breaks=c(1e4,2e4,3e4,4e4,5e4,6e4,7e4,8e4,9e4,1e5,1e5,2e5,3e5,4e5,5e5,6e5,7e5,8e5,9e5,1e6,2e6,3e6,4e6,5e6,6e6,7e6,8e6,9e6,1e7)) +
  scale_x_continuous(breaks=c(1e-7,1e-6,1e-5,1e-4)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(s_BDMi), fill=factor(s_BDMi))) +
  scale_fill_manual(values=c("#DC050C", "#1965B0")) +
  theme(legend.position="none")

Fig5 <- plot_grid(Fig5A, Fig5B, Fig5C, Fig5D, ncol=2)


##############################################
################## FIGURE 6 ##################
##############################################

Gavrilets <-function(mu) {1/mu}
Kimura <-function(Ne,mu) {4*Ne*((1/((4*Ne*mu)-1))*(-digamma(1)+digamma((4*Ne*mu))))}
Composite <- function(Ne,mu) {Gavrilets(mu)+(Kimura(Ne,(mu/2))-Gavrilets(mu/2))}

# Fig6T Time to fixation
Dataset_6T1 <- read_csv("S8_Table.csv") # no selection and symmetric selection (sa=sb)
Dataset_6T2 <- read_csv("S9_Table.csv") # asymmetric selection (sa>0 & sb=0)

Fig6T_1 <- ggplot(subset(Dataset_6T1,sa==0 & ha==0.5 & mu_Aa==2.5e-7), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(5e5,2e6)) +
  geom_function(fun=function(x) Gavrilets(5e-7), color = "grey90", size=1) + 
  geom_function(fun=function(x) Composite(1e4*((2-x)/2), 5e-7), color = "grey40", size=1) + 
  stat_summary(size=2, fun.data=mean_se, geom="point") +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6T_2 <- ggplot(subset(Dataset_6T2,sa==2e-4 & mu_Aa==2.5e-7), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(5e5,2e6)) +
  stat_summary(size=2, fun.data=mean_se, geom="point", shape=21, color="black", aes(group=factor(ha), fill=factor(ha))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6T_3 <- ggplot(subset(Dataset_6T1,sa==0 & ha==0.5 & mu_Aa==2.5e-6), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(1e5,3e5)) +
  geom_function(fun=function(x) Gavrilets(5e-6), color = "grey90", size=1) + 
  geom_function(fun=function(x) Composite(1e4*((2-x)/2), 5e-6), color = "grey40", size=1) + 
  stat_summary(size=2, fun.data=mean_se, geom="point") +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6T_4 <- ggplot(subset(Dataset_6T2,sa==2e-4 & mu_Aa==2.5e-6), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(1e5,3e5)) +
  stat_summary(size=2, fun.data=mean_se, geom="point", shape=21, color="black", aes(fill=factor(ha), colour=factor(ha))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6T_5 <- ggplot(subset(Dataset_6T1,sa==0 & ha==0.5 & mu_Aa==2.5e-5), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(2e4,1e5)) +
  geom_function(fun=function(x) Gavrilets(5e-5), color = "grey90", size=1) + 
  geom_function(fun=function(x) Composite(1e4*((2-x)/2), 5e-5), color = "grey40", size=1) +    
  stat_summary(size=2, fun.data=mean_se, geom="point") +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6T_6 <- ggplot(subset(Dataset_6T2,sa==2e-4 & mu_Aa==2.5e-5), aes(x=self_r, y=gen, group_by(ha))) +
  coord_trans(y="log10", ylim = c(2e4,1e5)) +
  stat_summary(size=2, fun.data=mean_se, geom="point", shape=21, color="black", aes(fill=factor(ha), colour=factor(ha))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig6_T <- plot_grid(Fig6T_1, Fig6T_2, Fig6T_3, Fig6T_4, Fig6T_5, Fig6T_6, ncol=2, nrow=3)


# Fig6P Phase portraits
PhaseDiagramDataset <- function(TheDataset) {
  
  Dataset.long <- pivot_longer(TheDataset, cols=c(22:(ncol(TheDataset)-1)), names_to = "label", values_to = "freq")
  Dataset.long$genotype <- str_sub(Dataset.long$label, 1, 5)
  Dataset.long$TimePoint <- as.numeric(str_sub(Dataset.long$label, 7))
  
  Dataset.wide <- pivot_wider(Dataset.long, id_cols=c(rep, N, rec, self_r, ha, sa, hb, sb, h_B, s_B, mu_Aa, TimePoint), names_from = genotype, values_from = freq)
  Dataset.wide$a <- 0.5 * (Dataset.wide$`AB/aB` + 
                             Dataset.wide$`AB/ab` + 
                             Dataset.wide$`Ab/aB` + 
                             Dataset.wide$`Ab/ab` +  
                             (2*Dataset.wide$`aB/aB`) +
                             (2*Dataset.wide$`aB/ab`) +
                             (2*Dataset.wide$`ab/ab`))
  Dataset.wide$b <- 0.5 * (Dataset.wide$`AB/Ab` + 
                             Dataset.wide$`AB/ab` + 
                             (2*Dataset.wide$`Ab/Ab`) + 
                             Dataset.wide$`Ab/aB` +  
                             (2*Dataset.wide$`Ab/ab`) +
                             Dataset.wide$`aB/ab` +
                             (2*Dataset.wide$`ab/ab`))
  
  return(Dataset.wide)
  
}
PhaseDiagramPlot <-function(replicat, TheDataset, TheDatasetWide) {
  
  Dataset_ID <- subset(TheDatasetWide, rep==replicat)
  
  N = unique(Dataset_ID$N)
  mu = unique(Dataset_ID$mu_Aa)
  self_r = unique(Dataset_ID$self_r)
  r = unique(Dataset_ID$rec)
  sa = unique(Dataset_ID$sa)
  ha = unique(Dataset_ID$ha)
  sb = unique(Dataset_ID$sb)
  hb = unique(Dataset_ID$hb)
  s_B = unique(Dataset_ID$s_B)
  h_B = unique(Dataset_ID$h_B)
  k_B = h_B
  gen = unique(subset(TheDataset, rep==replicat)$gen)
  
  F = self_r/(2-self_r)
  phi = ( (1-F)/(1-(2*F*r*(1-r))) ) + (2*F) - 1
  
  G11 = function(x,y) {(phi*(1-x)*(1-y)) + ((F-phi)*((((1-x)^2)*(1-y))+((1-x)*((1-y)^2)))) + ((1-(2*F)+phi)* ((1-x)^2) * ((1-y)^2)) } 
  G12 = function(x,y) {(2*(F-phi)*(1-x)*y*(1-y)) + (2*(1-(2*F)+phi)*((1-x)^2)*y*(1-y))}
  G13 = function(x,y) {(2*(F-phi)*x*(1-x)*(1-y)) + (2*(1-(2*F)+phi)*x*(1-x)*((1-y)^2))}
  G14 = function(x,y) {2*(1 - (2*F) + phi) * x * (1 - x) * y * (1 - y)}
  G22 = function(x,y) {(phi*(1-x)*y) + ((F-phi)*((((1-x)^2)*y)+((1-x)*(y^2)))) + ((1-(2*F)+phi)*((1-x)^2)*(y^2))}
  G23 = function(x,y) {2 * (1 - (2*F) + phi) * x * (1 - x) * y * (1 - y)}
  G24 = function(x,y) {(2 * (F-phi) * x * (1-x) * y) + (2 * (1-(2*F)+phi) * x * (1-x) * (y^2))}
  G33 = function(x,y) {(phi*(1-y)*x) + ((F-phi)*((((1-y)^2)*x)+((1-y)*(x^2)))) + ((1-(2*F)+phi)*((1-y)^2)*(x^2))}
  G34 = function(x,y) {(2 * (F-phi) * x * y * (1-y)) + ( 2 * (1-(2*F)+phi) * (x^2) * y * (1-y) )}
  G44 = function(x,y) {(phi*x*y) +( (F-phi) * (((x^2)*y) + (x*(y^2))) ) + ((1-(2*F)+phi))*(x^2)*(y^2)}
  
  length <- 100
  FitSurf <- expand.grid(X=c(0:length)/length,Y=c(0:length)/length)
  FitSurf$Fit <- sapply(X = FitSurf, function(X, Y) {N * (-s_B * 
                                                            (( G44(FitSurf$X,FitSurf$Y) ) +
                                                               ( h_B * G34(FitSurf$X,FitSurf$Y) ) +
                                                               ( h_B * G24(FitSurf$X,FitSurf$Y) ) +
                                                               ( h_B * k_B * G23(FitSurf$X,FitSurf$Y) ) + ( h_B * k_B * G14(FitSurf$X,FitSurf$Y) )))
  })[,1] 
  
  FitSurf$FitBis <- round(sapply(X = FitSurf, function(X, Y) {
    ((
      (G11(FitSurf$X,FitSurf$Y) * 1) +
        (G12(FitSurf$X,FitSurf$Y) * (1+(hb*sb)) ) +
        (G13(FitSurf$X,FitSurf$Y) * (1+(ha*sa)) ) +
        (G14(FitSurf$X,FitSurf$Y) * (1+(ha*sa)) * (1+(hb*sb)) * (1+(h_B*k_B*s_B)) ) +
        (G22(FitSurf$X,FitSurf$Y) * (1+sb) ) +
        (G23(FitSurf$X,FitSurf$Y) * (1+(ha*sa)) * (1+(hb*sb)) * (1+(h_B*k_B*s_B)) ) +
        (G24(FitSurf$X,FitSurf$Y) * (1+(ha*sa)) * (1+sb) * (1+(h_B*s_B)) ) +          
        (G33(FitSurf$X,FitSurf$Y) * (1+sa) ) +
        (G34(FitSurf$X,FitSurf$Y) * (1+sa) * (1+(hb*sb)) * (1+(h_B*s_B)) ) +
        (G44(FitSurf$X,FitSurf$Y) * (1+sa) * (1+sa) * (1+s_B) )             
    ) - 1) * (N*((2-self_r)/2))
  })[,1], digit=5)
  
  df <- expand.grid(a = ((1:10)-0.5)/10, b=((1:10)-0.5)/10)
  df$PopFit <- sapply(X = df, function(X, Y) {
    (
      (G11(df$a,df$b) * 1) +
        (G12(df$a,df$b) * (1+(hb*sb)) ) +
        (G13(df$a,df$b) * (1+(ha*sa)) ) +
        (G14(df$a,df$b) * (1+(ha*sa)) * (1+(hb*sb)) * (1+(h_B*k_B*s_B)) ) +
        (G22(df$a,df$b) * (1+sb) ) +
        (G23(df$a,df$b) * (1+(ha*sa)) * (1+(hb*sb)) * (1+(h_B*k_B*s_B)) ) +
        (G24(df$a,df$b) * (1+(ha*sa)) * (1+sb) * (1+(h_B*s_B)) ) +          
        (G33(df$a,df$b) * (1+sa) ) +
        (G34(df$a,df$b) * (1+sa) * (1+(hb*sb)) * (1+(h_B*s_B)) ) +
        (G44(df$a,df$b) * (1+sa) * (1+sa) * (1+s_B) )             
    )
  })[,1] 
  df$mu_a <- N * (mu * (1-df$a))
  df$mu_b <- N * (mu * (1-df$b))
  df$G11 <- G11(df$a,df$b)
  df$G12 <- G12(df$a,df$b)
  df$G13 <- G13(df$a,df$b)
  df$G14 <- G14(df$a,df$b)
  df$G22 <- G22(df$a,df$b)
  df$G23 <- G23(df$a,df$b)
  df$G24 <- G24(df$a,df$b)
  df$G33 <- G33(df$a,df$b)
  df$G34 <- G34(df$a,df$b)
  df$G44 <- G44(df$a,df$b)
  df$G11_fit <- 1
  df$G12_fit <- 1 + (hb*sb)
  df$G13_fit <- 1 + (ha*sa)
  df$G14_fit <- (1 + (ha*sa)) * (1 + (hb*sb)) * (1+(h_B*k_B*s_B))
  df$G22_fit <- 1+sb
  df$G23_fit <- (1 + (ha*sa)) * (1 + (hb*sb)) * (1+(h_B*k_B*s_B))
  df$G24_fit <- (1 + (ha*sa)) * (1+sb) * (1+(h_B*s_B))
  df$G33_fit <- 1+sa
  df$G34_fit <- (1+sa) * (1+ (hb*sb)) * (1+(h_B*s_B))
  df$G44_fit <- (1+sa) * (1+sb) * (1+s_B)
  df$s_a <- (N/(1+F))* (
    (df$G13*(df$G13_fit-1)) + 
      (df$G14*(df$G14_fit-1)) + 
      (df$G23*(df$G23_fit-1)) + 
      (df$G24*(df$G24_fit-1)) + 
      (2*df$G33*(df$G33_fit-1)) + 
      (2*df$G34*(df$G34_fit-1)) + 
      (2*df$G44*(df$G44_fit-1)))
  df$s_b <- (N/(1+F))* (
    (df$G12*(df$G12_fit-1)) + 
      (df$G14*(df$G14_fit-1)) + 
      (2*df$G22*(df$G22_fit-1)) + 
      (df$G23*(df$G23_fit-1)) + 
      (2*df$G24*(df$G24_fit-1)) + 
      (df$G34*(df$G34_fit-1)) + 
      (2*df$G44*(df$G44_fit-1)))
  df$RelS_a <- df$s_a / df$PopFit
  df$RelS_b <- df$s_b / df$PopFit
  df$muANDs_a <- df$mu_a+df$RelS_a
  df$muANDs_b <- df$mu_b+df$RelS_b
  for (i in 1:nrow(df)){
    df$angle[i] <- if(df$muANDs_a[i]>0 & df$muANDs_b[i]>0) {90-(atan(abs(df$muANDs_a[i])/abs(df$muANDs_b[i]))*(180/pi))
    } else if(df$muANDs_a[i]<0 & df$muANDs_b[i]>0) {180-(atan(abs(df$muANDs_b[i])/abs(df$muANDs_a[i]))*(180/pi))
    } else if(df$muANDs_a[i]<0 & df$muANDs_b[i]<0) {270-(atan(abs(df$muANDs_a[i])/abs(df$muANDs_b[i]))*(180/pi))
    } else if(df$muANDs_a[i]>0 & df$muANDs_b[i]<0) {360-(atan(abs(df$muANDs_b[i])/abs(df$muANDs_a[i]))*(180/pi))
    }}
  df$speed <- (df$muANDs_a)^2 + (df$muANDs_b)^2
  
  getPalette <- colorRampPalette(brewer.pal(n=11, name="Spectral")[5:11])
  
  ggplot(FitSurf, aes(X,Y, z=FitBis)) +
    ggtitle(paste("N:",N, "| mu:", mu, "| self_r:",self_r, "| r:",r, "| h_B:",h_B,"| s_BDMi:",s_B,"| gen:",gen)) +
    geom_contour_filled(size=1, colour= "black", breaks=c(-50,-10:2)) +
    scale_fill_discrete(type=c("#000000",rev(getPalette(13))),drop=FALSE) +
    geom_point(data=Dataset_ID, aes(x=a, y=b, z=0, alpha=0.1), colour="grey10") +
    geom_path(data=Dataset_ID, aes(x=a, y=b, z=0, alpha=0.1), colour="grey10") +
    theme_classic(base_size=17) +
    theme(aspect.ratio=1) +
    geom_spoke(data=df, size=log(x=df$speed+1, base=100), arrow=arrow(length=unit(log(x=df$speed+1,base=100)/4,"cm"), type="open"), colour="grey20", aes(x=a,y=b,z=0, angle=(as.numeric(angle)*pi)/(180), radius=10^-10)) +
    theme(axis.text = element_blank(), axis.title = element_blank(), legend.position="none", strip.background = element_blank(), strip.text = element_blank())
}

Dataset_6P_1 <- read_csv("S10_Table.csv") # no selection and symmetric selection (sa=sb)

Dataset_6P_1[,c(22:(ncol(Dataset_6P_1)))] <- sapply(Dataset_6P_1[,c(22:(ncol(Dataset_6P_1)))], as.numeric)
Dataset_6P_1$rep <- c(1:nrow(Dataset_6P_1))
Dataset_6P_1.wide <- PhaseDiagramDataset(Dataset_6P_1)

rept <- unique(subset(Dataset_6P_1.wide, sa==0 & self_r==0 & mu_Aa==2.5e-7)$rep)
cbind(rept,subset(Dataset_6P_1,rep %in% rept)$gen)

Fig6P_1 <- PhaseDiagramPlot(46, Dataset_6P_1, Dataset_6P_1.wide)
Fig6P_2 <- PhaseDiagramPlot(86, Dataset_6P_1, Dataset_6P_1.wide)
Fig6P_3 <- PhaseDiagramPlot(167, Dataset_6P_1, Dataset_6P_1.wide)
Fig6P_4 <- PhaseDiagramPlot(181, Dataset_6P_1, Dataset_6P_1.wide)
Fig6P_5 <- PhaseDiagramPlot(287, Dataset_6P_1, Dataset_6P_1.wide)
Fig6P_6 <- PhaseDiagramPlot(349, Dataset_6P_1, Dataset_6P_1.wide)

Dataset_Fig6P_2 <- read_csv("S11_Table.csv") # asymmetric selection (sa>0 & sb=0)

Dataset_Fig6P_2[,c(22:(ncol(Dataset_Fig6P_2)))] <- sapply(Dataset_Fig6P_2[,c(22:(ncol(Dataset_Fig6P_2)))], as.numeric)
Dataset_Fig6P_2$rep <- c(1:nrow(Dataset_Fig6P_2))
Dataset_Fig6P_2.wide <- PhaseDiagramDataset(Dataset_Fig6P_2)

rept <- unique(subset(Dataset_Fig6P_2.wide, sa==2e-4 & self_r==1 & mu_Aa==2.5e-5 & ha==0.9 )$rep)
cbind(rept,subset(Dataset_Fig6P_2,rep %in% rept)$gen)

Fig6P_7 <- PhaseDiagramPlot(11, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_8 <- PhaseDiagramPlot(8, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_9 <- PhaseDiagramPlot(21, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_10 <- PhaseDiagramPlot(37, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_11 <- PhaseDiagramPlot(46, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_12 <- PhaseDiagramPlot(56, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)

Fig6P_13 <- PhaseDiagramPlot(62, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_14 <- PhaseDiagramPlot(84, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_15 <- PhaseDiagramPlot(69, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_16 <- PhaseDiagramPlot(93, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_17 <- PhaseDiagramPlot(106, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)
Fig6P_18 <- PhaseDiagramPlot(120, Dataset_Fig6P_2, Dataset_Fig6P_2.wide)

Fig6P_col1 <- plot_grid(Fig6P_1, Fig6P_4, Fig6P_2, Fig6P_5, Fig6P_3, Fig6P_6, ncol=2)
Fig6P_col2 <- plot_grid(Fig6P_7, Fig6P_13, Fig6P_8, Fig6P_14, Fig6P_9, Fig6P_15, ncol=2)
Fig6P_col3 <- plot_grid(Fig6P_10, Fig6P_16, Fig6P_11, Fig6P_17, Fig6P_12, Fig6P_18, ncol=2)


##############################################
################## FIGURE 7 ##################
##############################################

Dataset_Fig7T_1 <- read_csv("S12_Table.csv")
Dataset_Fig7T_2 <- read_csv("S13_Table.csv")

Fig7A_T <- ggplot(subset(Dataset_Fig7T_1,mu_Aa==2.5e-5), aes(x=self_r, y=gen, group_by(s_B))) +
  geom_function(fun=function(x) Gavrilets(5e-5), color = "grey90", size=1) + 
  geom_function(fun=function(x) Composite(1e4*((2-x)/2), 5e-5), color = "grey40", size=1) + 
  stat_summary(size=2, fun.data=mean_se, geom="point", shape=21, aes(group=factor(s_B), fill=factor(s_B))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Fig7B_T <- ggplot(subset(Dataset_Fig7T_2,mu_Aa==2.5e-5), aes(x=self_r, y=gen, group_by(h_B))) +
  geom_function(fun=function(x) Gavrilets(5e-5), color = "grey90", size=1) + 
  geom_function(fun=function(x) GavriletsNe(1e4*((2-x)/2), 5e-5), color = "grey60", size=1) +
  geom_function(fun=function(x) Composite(1e4*((2-x)/2), 5e-5), color = "grey40", size=1) + 
  stat_summary(size=2, fun.data=mean_se, geom="point", shape=21, aes(group=factor(h_B), fill=factor(h_B))) +
  scale_fill_manual(values=c("#7BAFDE", "#4EB265", "#CAE0AB")) +
  theme_classic(base_size=17) +
  theme(legend.position="none", axis.text=element_blank(), axis.title = element_blank(), aspect.ratio=1)

Dataset_Fig7P_1 <- read_csv("S14_Table.csv")
Dataset_Fig7P_1[,c(22:(ncol(Dataset_Fig7P_1)))] <- sapply(Dataset_Fig7P_1[,c(22:(ncol(Dataset_Fig7P_1)))], as.numeric)
Dataset_Fig7P_1$rep <- c(1:nrow(Dataset_Fig7P_1))
Dataset_Fig7P_1.wide <- PhaseDiagramDataset(Dataset_Fig7P_1)

rept <- unique(subset(Dataset_Fig7P_1.wide2, self_r==1 & s_B==-2.5e-3)$rep)
cbind(rept,subset(Dataset_Fig7P_1,rep %in% rept)$gen)

Fig7A_P1 <- PhaseDiagramPlot(8, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==0 & s_B==0
Fig7A_P2 <- PhaseDiagramPlot(16, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==0 & s_B==2.5e-4
Fig7A_P3 <- PhaseDiagramPlot(25, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==0 & s_B==2.5e-3
Fig7A_P4 <- PhaseDiagramPlot(35, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==1 & s_B==0
Fig7A_P5 <- PhaseDiagramPlot(46, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==1 & s_B==2.5e-4
Fig7A_P6 <- PhaseDiagramPlot(52, Dataset_Fig7P_1, Dataset_Fig7P_1.wide) #self_r==1 & s_B==2.5e-3

Fig7A_P <- plot_grid(Fig7A_P1, Fig7A_P4, Fig7A_P2, Fig7A_P5, Fig7A_P3, Fig7A_P6, ncol=2)

Dataset_Fig7P_2 <- read_csv("S15_Table.csv")
Dataset_Fig7P_2[,c(22:(ncol(Dataset_Fig7P_2)))] <- sapply(Dataset_Fig7P_2[,c(22:(ncol(Dataset_Fig7P_2)))], as.numeric)
Dataset_Fig7P_2$rep <- c(1:nrow(Dataset_Fig7P_2))
Dataset_Fig7P_2.wide <- PhaseDiagramDataset(Dataset_Fig7P_2)

rept <- unique(subset(Dataset_Fig7P_2.wide,self_r==1 & h_B==0.9)$rep)
cbind(rept,subset(Dataset_Fig7P_2,rep %in% rept)$gen)

Fig7A_P7 <- PhaseDiagramPlot(7, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==0 & h_B==0.1
Fig7A_P8 <- PhaseDiagramPlot(14, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==0 & h_B==0.5
Fig7A_P9 <- PhaseDiagramPlot(24, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==0 & h_B==0.9
Fig7A_P10 <- PhaseDiagramPlot(37, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==1 & h_B==0.1
Fig7A_P11 <- PhaseDiagramPlot(44, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==1 & h_B==0.5
Fig7A_P12 <- PhaseDiagramPlot(54, Dataset_Fig7P_2, Dataset_Fig7P_2.wide) #self_r==1 & h_B==0.9

Fig7B_P <- plot_grid(Fig7A_P7, Fig7A_P10, Fig7A_P8, Fig7A_P11, Fig7A_P9, Fig7A_P12, ncol=2)


##############################################
################## FIGURE 8 ##################
##############################################

setwd("~/5. Work Oslo & Rennes/3. MSRI_Allopatry/3. BDMi/1. TwoLoci")
Dataset_Fig8_1 <- read_csv("S16_Table.csv") # no sel & symmetric sel (mu=2.510e-6)
Dataset_Fig8_2 <- read_csv("S17_Table.csv") # no sel & symmetric sel (mu=2.510e-5)
Dataset_Fig8_3 <- read_csv("S18_Table.csv") # asymmetric selection

Fig8_1 <- ggplot(subset(Dataset_Fig8_1,sa==0), aes(x=self_r, y=gen, group_by(BG))) +
  coord_trans(y="log10", ylim = c(10^4.8,10^5.5)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(BG), fill=factor(BG))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme(legend.position="none")

Fig8_2 <- ggplot(subset(Dataset_Fig8_3,mu_Aa==2.5e-6), aes(x=self_r, y=gen, group_by(BG))) +
  coord_trans(y="log10", ylim = c(10^4.8,10^5.5)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(BG), fill=factor(BG))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme(legend.position="none")

Fig8_3 <- ggplot(subset(Dataset_Fig8_2,sa==0), aes(x=self_r, y=gen, group_by(BG))) +
  coord_trans(y="log10", ylim = c(18000,80000)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(BG), fill=factor(BG))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme(legend.position="none")

Fig8_4 <- ggplot(subset(Dataset_Fig8_3,mu_Aa==2.5e-5), aes(x=self_r, y=gen, group_by(BG))) +
  coord_trans(y="log10", ylim = c(18000,80000)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(BG), fill=factor(BG))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#1965B0")) +
  theme(legend.position="none")

Fig8 <- plot_grid(Fig8_1, Fig8_2, Fig8_3, Fig8_4, ncol=2, nrow=2) # no sel vs asymmetric sel


##############################################
################## FIGURE 9 ##################
##############################################

Dataset_Fig9 <- read_csv("S19_Table.csv") # asymmetric sel

Fig9 <- ggplot(Dataset_Fig9, aes(x=self_r, y=gen, group_by(sa_out))) +
  coord_trans(y="log10", ylim = c(NA,NA)) +
  theme_classic(base_size=17) +
  theme(aspect.ratio=1) +
  stat_summary(size=3, fun.data=mean_se, geom="point", shape=21, aes(group=factor(sa_out), fill=factor(sa_out))) +
  scale_fill_manual(values=c("#DC050C", "#F7F056", "#4EB265", "#1965B0")) +
  theme(legend.position="none")
